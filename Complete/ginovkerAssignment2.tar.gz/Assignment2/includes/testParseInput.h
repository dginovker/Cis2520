/**
 * @file testParseInput.h
 * @author Daniel Ginovker
 * @date October 2017
 * @brief File containing the function definitions used in testing the parseinput functions
 */


#ifndef TESTPARSEINPUT_H
#define TESTPARSEINPUT_H

int testParseInput();

#endif
