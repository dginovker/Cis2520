****************************************************
Daniel Ginovker, 0954042
Data Structures, 0106 - Lab 8
DATE, dcress01@mail.uoguelph.ca
****************************************************

************
Compilation
************
Run make to compile the file. Compiled file is put in /bin/main.out

***********************
Running the program(s)
***********************
Run the program as you would normally. Entering anything other than integers at integer prompt will not crash
program but might give unintended results. Integers entered into the list to be sorted must be entered, seperated
by new-lines.

*****************
Known Limitations
*****************
Messing with input can cause unintended side-effects.
