#ifndef DISPLAYDICTIONARY_H
#define DISPLAYDICTIONARY_H

/* Showdictionary words: Function that prints all words in the hashmap
* @param HTable: hashmap that has all the dictionary words
* @return void
*/
void showDictionaryWords(HTable *hashmap);

#endif
