#include "../includes/simulation.h"

int main( int argc, char ** argv)
{
	runSimulation();
	return 0;
}
