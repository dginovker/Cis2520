****************************************************
Daniel Ginovker, 0954042
Data Structures, 0106 - Lab 11
DATE, dcress01@mail.uoguelph.ca
****************************************************

************
Compilation
************
"make testing" produces the testing file, and is stored in /bin as "testMain.out"
"make" produces the main program, and is storing in /bin as "main.out"

***********************
Running the program(s)
***********************
There is no additional information required to run the program.

It should be noted the insertion algorithm used slightly differs than that of James Fraser and as a result gives slightly
different output, but the order is still correct as far as a heap is concerned.

*****************
Known Limitations
*****************
There are no known limitations.
